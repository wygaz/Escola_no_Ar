from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import FormularioCadastro

def cadastro(request):
    if request.method == 'POST':
        form = FormularioCadastro(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Cadastro realizado com sucesso!')
            return redirect('login')
    else:
        form = FormularioCadastro()
    return render(request, 'usuarios/cadastro.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        senha = request.POST.get('password')
        usuario = authenticate(request, email=email, password=senha)
        if usuario:
            login(request, usuario)
            return redirect('perfil_usuario')
        else:
            messages.error(request, 'E-mail ou senha inválidos.')
    return render(request, 'usuarios/login.html')

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def perfil_usuario(request):
    return render(request, 'usuarios/perfil.html')

@login_required
def alterar_imagem(request):
    if request.method == 'POST' and request.FILES.get('foto_perfil'):
        usuario = request.user
        usuario.foto_perfil = request.FILES['foto_perfil']
        usuario.save()
        messages.success(request, 'Imagem alterada com sucesso.')
    return redirect('perfil_usuario')

@login_required
def alterar_senha(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Senha alterada com sucesso.')
            return redirect('perfil_usuario')
        else:
            messages.error(request, 'Corrija os erros abaixo.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'usuarios/perfil.html', {'form': form})
