from django.contrib.auth.models import AbstractUser
from django.db import models

class Usuario(AbstractUser):
    nome_completo = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    tipo = models.CharField(max_length=20, choices=[('aluno', 'Aluno'), ('professor', 'Professor')])
    foto_perfil = models.ImageField(upload_to='usuarios/fotos/', blank=True, null=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']
