from django.urls import path
from . import views

urlpatterns = [
    path('cadastro/', views.cadastro, name='cadastro'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('perfil/', views.perfil_usuario, name='perfil_usuario'),
    path('alterar-imagem/', views.alterar_imagem, name='alterar_imagem'),
    path('alterar-senha/', views.alterar_senha, name='alterar_senha'),
]
